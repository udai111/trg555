import StockMarketGame from "@/components/StockMarketGame";

export default function StockMarketGamePage() {
  return (
    <div className="container mx-auto">
      <StockMarketGame />
    </div>
  );
}